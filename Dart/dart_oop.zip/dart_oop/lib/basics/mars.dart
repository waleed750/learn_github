// import 'dart:math';

/*
void main() {
  // Variables ——————————————————
  var number = 50; // int
  var float = 3.14; // double
  
  // number = 20;
  // number = float;

  print(number);
}
*/


import 'dart:math';

// void main() {
//   // Data Types —————————————————
//   int number = 20;
//   double float = 2.718;
  
//   // number = float; 

//   number = 30;

//   print(number);
//   // ——————————

//   dynamic iCanHoldAnyThing;

//   iCanHoldAnyThing = 0.5;
//   iCanHoldAnyThing = 1000;
//   iCanHoldAnyThing = true;
//   iCanHoldAnyThing = "Hello World";
//   // ————————————————————
//   const Name = "Mohammed";

//   final username = Random().nextInt(3);

//   // Try to change …
// }


/*
 void main() {
  // Null ——————————————————————
  int id;
  int age, number;
  String? name;

  final String username = name ??  "Username";
  id = 2 ;
  print(id);
  // ??= , ?. , !., , late, nullable

  // Operators ——————————————————
  // +=, -=, *=, /=, ~/=, %=, 

  // ==, !=, >, <, >=, <=, &&, ||, !

  // ++, -- => في البداية مختلف عن في النهاية
}*/



// void main() {
//   // Strings ————————————————————
//   var firstName = "Khadija";
//   String lastName = 'Ahmed';

//   final fullName = firstName + " " + lastName;
//   "$firstName ${lastName}";

//   // \ (تخطي الرمز بعدها) {\'  - \$  - \"}, \t, \n

//   var model = """Hello
//   World""";

//   print(model);

//   const raw = r"I'll\nbe\nback";

//   print(raw);
// }


/*
void main() {
  // Conditions ——————————————————
  if else if else 
  Nested if 
  Ternary Operator (isTrue ? Yes : No) 

  Switch statement
  // (Two Cases and break)
  case 
  case
  break

  // (One Case and break)
  case
  break

  // (Case and return)
  case
  return

  // (Default Case)
  default 
}
*/

/*
void main() {
  // Loops —————————————————————
  // for loop: (normal loop), (var .. in loop), 

  // for each (function) like (print), (("anonymous function") (body) / (full))

  // While loop
  // Do while loop
  // Break , Continue 
}
*/

/*
void main() {
  // Functions ———————————————————
  // normal with return
  // normal without return (void functino)

  // Arguments: [optional] / required / {named parameters} 
  // Default Arguments Values
  // Can give function or null too in Arguments

  String SayHello(String name) => "Hello $name";

  // Anonymous Function
  var multiply = (int a, int b) {
    return a * b;
  };

  // Closures
  Function multi(num multi) {
    return (num value) => value * multi;
  }

  var triple = multi(3);
  
  print(triple(3));
}
*/