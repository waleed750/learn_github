
import 'package:dart_oop/oop/staff/actor.dart';

void main(List<String> args) {
  Actor actor = Actor(name: "waleed", filmography: ["fasfas" , " dsadasd"],
   lastName: "ashraf");
  
  actor.printAllData();

}