/*
*enum enumName {
  constantName1,
  constantName2,
  constantName3,
  ...
  !constantNameN
}

*/
enum Days { Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday }



  
// void main() {
//   var today = Days.Friday;
//   switch (today) {
//     case Days.Sunday:
//       print("Today is Sunday.");
//       break;
//     case Days.Monday:
//       print("Today is Monday.");
//       break;
//     case Days.Tuesday:
//       print("Today is Tuesday.");
//       break;
//     case Days.Wednesday:
//       print("Today is Wednesday.");
//       break;
//     case Days.Thursday:
//       print("Today is Thursday.");
//       break;
//     case Days.Friday:
//       print("Today is Friday.");
//       break;
//     case Days.Saturday:
//       print("Today is Saturday.");
//       break;
//   }
// }
//*Enhanced Enum 

// enum CompanyType {
//   soleProprietorship("Sole Proprietorship"),
//   partnership("Partnership"),
//   corporation("Corporation"),
//   limitedLiabilityCompany("Limited Liability Company");
//   // Members
//   String text;
//   const CompanyType(this.text);
  

// }
void main(List<String> args) {
  
}