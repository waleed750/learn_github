class Human{
  double? length;
  Color? eyecolor;
  Hand? hands;
}

class Color {
  //RGB
  int red = 0 ;
  int green = 0 ;
  int blue = 0 ;
}
class Hand {
  //Fingers 
  int fingerNumber = 0 ;
}
